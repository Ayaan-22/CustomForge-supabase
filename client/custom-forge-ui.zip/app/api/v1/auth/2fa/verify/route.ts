import { ok } from "../../../_utils"
export async function POST() {
  return ok({ message: "2FA verified (mock)" })
}
