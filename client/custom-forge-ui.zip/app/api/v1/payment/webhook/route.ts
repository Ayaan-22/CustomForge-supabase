import { ok } from "../../_utils"
export async function POST() {
  return ok({ received: true })
}
