import { ok } from "../../../_utils"
export async function PATCH() {
  return ok({ message: "Password updated (mock)" })
}
