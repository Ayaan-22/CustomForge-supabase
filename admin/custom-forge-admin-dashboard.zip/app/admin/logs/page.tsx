"use client"

import type React from "react"
import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ChevronDown, AlertCircle, Info, AlertTriangle } from "lucide-react"
import { LogDetailsModal } from "../components/log-details-modal"

const mockLogs = [
  {
    id: 1,
    date: "2024-01-15 14:32:45",
    level: "info",
    action: "User login",
    admin: "John Doe",
    details: { userId: 123, email: "user@example.com", ip: "192.168.1.1" },
  },
  {
    id: 2,
    date: "2024-01-15 14:28:12",
    level: "warn",
    action: "Failed login attempt",
    admin: "System",
    details: { email: "unknown@example.com", attempts: 3, ip: "192.168.1.50" },
  },
  {
    id: 3,
    date: "2024-01-15 14:15:33",
    level: "info",
    action: "Product created",
    admin: "Jane Smith",
    details: { productId: 456, name: "Gaming Headset Pro", price: 199.99 },
  },
  {
    id: 4,
    date: "2024-01-15 14:05:22",
    level: "error",
    action: "Payment processing failed",
    admin: "System",
    details: { orderId: "ORD-1001", error: "Insufficient funds", amount: 234.5 },
  },
  {
    id: 5,
    date: "2024-01-15 13:55:11",
    level: "info",
    action: "Order shipped",
    admin: "Bob Johnson",
    details: { orderId: "ORD-1002", trackingNumber: "TRK123456789", carrier: "FedEx" },
  },
  {
    id: 6,
    date: "2024-01-15 13:45:00",
    level: "warn",
    action: "Inventory low",
    admin: "System",
    details: { productId: 789, productName: "Gaming Mouse Ultra", stock: 3 },
  },
  {
    id: 7,
    date: "2024-01-15 13:30:45",
    level: "info",
    action: "Coupon created",
    admin: "Jane Smith",
    details: { couponCode: "SAVE20", discount: 20, type: "percentage" },
  },
  {
    id: 8,
    date: "2024-01-15 13:20:30",
    level: "error",
    action: "Database connection error",
    admin: "System",
    details: { error: "Connection timeout", retries: 3, duration: "5s" },
  },
]

const levelColors: Record<string, string> = {
  info: "bg-blue-500/20 text-blue-400",
  warn: "bg-yellow-500/20 text-yellow-400",
  error: "bg-red-500/20 text-red-400",
}

const levelIcons: Record<string, React.ReactNode> = {
  info: <Info className="w-4 h-4" />,
  warn: <AlertTriangle className="w-4 h-4" />,
  error: <AlertCircle className="w-4 h-4" />,
}

export default function LogsPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [levelFilter, setLevelFilter] = useState("all")
  const [expandedLog, setExpandedLog] = useState<number | null>(null)
  const [selectedLog, setSelectedLog] = useState<any>(null)
  const [isDetailsOpen, setIsDetailsOpen] = useState(false)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 5

  const filteredLogs = mockLogs.filter((log) => {
    const matchesSearch =
      log.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.admin.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesLevel = levelFilter === "all" || log.level === levelFilter
    return matchesSearch && matchesLevel
  })

  const totalPages = Math.ceil(filteredLogs.length / itemsPerPage)
  const paginatedLogs = filteredLogs.slice((currentPage - 1) * itemsPerPage, currentPage * itemsPerPage)

  const handleViewDetails = (log: any) => {
    setSelectedLog(log)
    setIsDetailsOpen(true)
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-white">Logs</h1>
        <p className="text-[#A0A0A8] mt-1">View system activity logs</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col md:flex-row gap-4">
        <Input
          placeholder="Search logs..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="bg-[#1F1F28] border-[#2A2A35] text-white placeholder:text-[#A0A0A8]"
        />

        <select
          value={levelFilter}
          onChange={(e) => setLevelFilter(e.target.value)}
          className="px-4 py-2 bg-[#1F1F28] border border-[#2A2A35] text-white rounded-lg"
        >
          <option value="all">All Levels</option>
          <option value="info">Info</option>
          <option value="warn">Warning</option>
          <option value="error">Error</option>
        </select>
      </div>

      {/* Logs Table */}
      <Card className="glass-dark p-6 border-[#2A2A35]">
        <div className="space-y-2">
          {paginatedLogs.map((log) => (
            <div key={log.id}>
              <button
                onClick={() => handleViewDetails(log)}
                className={`w-full flex items-center justify-between p-4 hover:bg-[#1F1F28] rounded-lg transition-colors border border-[#2A2A35] ${
                  log.level === "error" ? "bg-red-500/5" : ""
                }`}
              >
                <div className="flex items-center gap-4 flex-1 text-left">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-1 ${levelColors[log.level]}`}
                  >
                    {levelIcons[log.level]}
                    {log.level.toUpperCase()}
                  </span>

                  <div>
                    <p className="text-white font-medium">{log.action}</p>
                    <p className="text-[#A0A0A8] text-sm">{log.admin}</p>
                  </div>
                </div>

                <div className="hidden md:flex items-center gap-8">
                  <p className="text-[#A0A0A8] text-sm w-40">{log.date}</p>
                </div>

                <ChevronDown
                  className={`w-5 h-5 text-[#A0A0A8] transition-transform ${expandedLog === log.id ? "rotate-180" : ""}`}
                />
              </button>
            </div>
          ))}
        </div>
      </Card>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
            disabled={currentPage === 1}
            className="px-4 py-2 bg-[#1F1F28] border border-[#2A2A35] text-white rounded-lg disabled:opacity-50"
          >
            Previous
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
            <button
              key={page}
              onClick={() => setCurrentPage(page)}
              className={`px-3 py-2 rounded-lg transition-colors ${
                currentPage === page
                  ? "bg-gradient-to-r from-[#7C3AED] to-[#3B82F6] text-white"
                  : "bg-[#1F1F28] border border-[#2A2A35] text-white hover:bg-[#2A2A35]"
              }`}
            >
              {page}
            </button>
          ))}

          <button
            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
            disabled={currentPage === totalPages}
            className="px-4 py-2 bg-[#1F1F28] border border-[#2A2A35] text-white rounded-lg disabled:opacity-50"
          >
            Next
          </button>
        </div>
      )}

      {/* Log Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="glass-dark p-6 border-[#2A2A35]">
          <p className="text-[#A0A0A8] text-sm font-medium">Total Logs</p>
          <p className="text-2xl font-bold text-white mt-2">{mockLogs.length}</p>
        </Card>
        <Card className="glass-dark p-6 border-[#2A2A35]">
          <p className="text-[#A0A0A8] text-sm font-medium">Info</p>
          <p className="text-2xl font-bold text-blue-400 mt-2">{mockLogs.filter((l) => l.level === "info").length}</p>
        </Card>
        <Card className="glass-dark p-6 border-[#2A2A35]">
          <p className="text-[#A0A0A8] text-sm font-medium">Warnings</p>
          <p className="text-2xl font-bold text-yellow-400 mt-2">{mockLogs.filter((l) => l.level === "warn").length}</p>
        </Card>
        <Card className="glass-dark p-6 border-[#2A2A35]">
          <p className="text-[#A0A0A8] text-sm font-medium">Errors</p>
          <p className="text-2xl font-bold text-red-400 mt-2">{mockLogs.filter((l) => l.level === "error").length}</p>
        </Card>
      </div>

      {/* Log Details Modal */}
      <LogDetailsModal isOpen={isDetailsOpen} onClose={() => setIsDetailsOpen(false)} log={selectedLog} />
    </div>
  )
}
