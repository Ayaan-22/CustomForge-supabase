import { ok } from "../../../_utils"
export async function DELETE() {
  return ok({ message: "2FA disabled (mock)" })
}
