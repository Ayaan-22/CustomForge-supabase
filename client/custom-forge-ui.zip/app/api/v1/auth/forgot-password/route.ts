import { ok } from "../../_utils"
export async function POST() {
  return ok({ message: "Password reset email sent (mock)" })
}
